#!/bin/sh

sh ./wlanoff.sh 
sleep 10
sh ./wlanon.sh

echo "WLAN Connections were RESET"