#!/bin/sh

iptables -I FORWARD -m mac --mac-source 04:4B:ED:27:F3:6A -j DROP #Gi - iPhone 6s

