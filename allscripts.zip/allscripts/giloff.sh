#!/bin/sh

iptables -I FORWARD -m mac --mac-source 60:6D:C7:DA:0C:21 -j DROP #Gi - Laptop
