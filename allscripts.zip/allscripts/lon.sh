#!/bin/sh

iptables -D FORWARD -m mac --mac-source 60:6D:C7:DA:B5:39 -j DROP #Bri - Laptop
iptables -D FORWARD -m mac --mac-source 60:6D:C7:DA:0C:21 -j DROP #Gi - Laptop
iptables -D FORWARD -m mac --mac-source 60:6D:C7:DA:7F:B7 -j DROP #Eli - Laptop
