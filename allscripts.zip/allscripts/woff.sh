#!/bin/sh

ifconfig ath0 down
ifconfig ath1 down