#!/bin/sh

iptables -I FORWARD -m mac --mac-source 8C:29:37:20:E6:A1 -j DROP #Bri - iPhone 5s
iptables -I FORWARD -m mac --mac-source 04:4B:ED:27:F3:6A -j DROP #Gi - iPhone 6s
iptables -I FORWARD -m mac --mac-source C0:1A:DA:9A:3F:E1 -j DROP #Eli - iPhone 5s
