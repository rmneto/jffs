#!/bin/sh
DOW=$(date +%u)
TOD=$(date +%H%M)

echo "Day of Week is $DOW"
echo "Time is $TOD"

#iptables -F FORWARD

case $DOW in
	*) echo "Weekday"
		if [ $TOD -gt 2259 ] && [ $TOD -lt 0701 ] 
		then
		   echo "ON"
		   #iptables -F FORWARD
		   sh ./on.sh
		else
		   echo "OFF"
		   sh ./off.sh
		fi
	;;
esac
