DOW=$(date +%u)
TOD=$(date +%H%M)

echo "Day of Week is $DOW"
echo "Time is $TOD"

iptables -F FORWARD

if [ $DOW -eq 5 ] || [ $DOW -eq 6 ]
then
   echo "Weekend"

	if [ $TOD -gt 1500 ] && [ $TOD -lt 2100 ] 
	then
	   echo "ON"
           sh pon.sh
	else
	   echo "OFF"
           sh poff.sh
	fi
else
   echo "Weekday"
	if [ $TOD -gt 1800 ] && [ $TOD -lt 2100 ] 
	then
	   echo "ON"
           sh pon.sh
	else
	   echo "OFF"
           sh poff.sh
	fi
fi