#!/bin/sh

stopservice wan
