#!/bin/sh

#iptables -D FORWARD -m mac --mac-source F0:98:9D:37:04:A2 -j DROP #RUI - iPhone
#iptables -D FORWARD -m mac --mac-source 8C:29:37:20:E6:A1 -j DROP #Bri - iPhone 5s
#iptables -D FORWARD -m mac --mac-source 60:6D:C7:DA:B5:39 -j DROP #Bri - Laptop
#iptables -D FORWARD -m mac --mac-source 04:4B:ED:27:F3:6A -j DROP #Gi - iPhone 6s
#iptables -D FORWARD -m mac --mac-source 60:6D:C7:DA:0C:21 -j DROP #Gi - Laptop
#iptables -D FORWARD -m mac --mac-source C0:1A:DA:9A:3F:E1 -j DROP #Eli - iPhone 5s
#iptables -D FORWARD -m mac --mac-source 60:6D:C7:DA:7F:B7 -j DROP #Eli - Laptop
#iptables -D FORWARD -m mac --mac-source 00:19:D1:12:39:D2 -j DROP #kids - Desktop
#iptables -D FORWARD -m mac --mac-source 00:23:54:1F:F4:60 -j DROP #kids - Desktop2

iptables -F FORWARD

touch ./online.status

echo "Devices are ONLINE with OVERRIDE"