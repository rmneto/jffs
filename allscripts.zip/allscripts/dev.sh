#!/bin/sh
sh ./_dev.sh > dev.log
