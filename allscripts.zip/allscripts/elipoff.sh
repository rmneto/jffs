#!/bin/sh

iptables -I FORWARD -m mac --mac-source C0:1A:DA:9A:3F:E1 -j DROP #Eli - iPhone 5s
