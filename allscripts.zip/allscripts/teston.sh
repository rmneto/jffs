#!/bin/sh

iptables -D FORWARD -m mac --mac-source F0:98:9D:37:04:A2 -j DROP #Rui - iPhone
