#!/bin/sh

iptables -I FORWARD -m mac --mac-source 8C:29:37:20:E6:A1 -j DROP #Bri - iPhone 5s
