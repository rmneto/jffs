#!/bin/sh

rm ./online.status

echo "OVERRIDE is disabled"