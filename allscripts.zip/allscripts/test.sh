#!/bin/sh

rules=["iptables -I FORWARD -m mac --mac-source F0:98:9D:37:04:A2 -j DROP"]

for rule in "${rules[@]}"
do
    #iptables -L -n | grep -q "$rule" && echo "$rule exists" || echo "$rule does not exist"
    echo "${rule}"
done