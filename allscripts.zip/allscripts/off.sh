#!/bin/sh

file="./online.status"
if [ -f "$file" ]
then

    echo "Devices are ONLINE with OVERRIDE"
else

    iptables -I FORWARD -m mac --mac-source 8C:29:37:20:E6:A1 -j DROP #Bri - iPhone 5s
    iptables -I FORWARD -m mac --mac-source 04:4B:ED:27:F3:6A -j DROP #Gi - iPhone 6s
    iptables -I FORWARD -m mac --mac-source C0:1A:DA:9A:3F:E1 -j DROP #Eli - iPhone 5s

    iptables -I FORWARD -m mac --mac-source 10:BF:48:87:05:D0 -j DROP #kids - Desktop
    iptables -I FORWARD -m mac --mac-source 00:23:54:1F:F4:60 -j DROP #kids - Desktop2
 
    iptables -I FORWARD -m mac --mac-source EC:C4:0D:F5:7E:2D -j DROP #Nintendo Switch Wireless
    iptables -I FORWARD -m mac --mac-source 00:90:9E:9D:A5:31 -j DROP #Nintendo Switch Wired

    #iptables -I FORWARD -m mac --mac-source F0:98:9D:37:04:A2 -j DROP #RUI - iPhone

    echo "Devices are OFFLINE"

fi

#sh ./wreset.sh