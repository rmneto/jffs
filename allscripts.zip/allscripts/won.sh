#!/bin/sh

ifconfig ath0 up
ifconfig ath1 up
