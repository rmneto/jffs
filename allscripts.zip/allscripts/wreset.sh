#!/bin/sh

sh ./woff.sh
sleep 10
sh ./won.sh

echo "Wireless Connections were RESET"