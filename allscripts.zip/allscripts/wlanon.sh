#!/bin/sh

startservice wan
